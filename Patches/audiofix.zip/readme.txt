Audio library patch disc instructions:
09.30.11

1) Burn a cd from the attached iso.
2) Let the game boot up completely.
3) Attach a keyboard, press F1.
4) Log in (user:root password:nucore.)
5) Type gdm start
6) Log into GDM (user:root password:nucore.)
7) Insert the CD rom you created and when prompted choose run.  
8) Reboot the machine.

This should fix any problems with the audio cutting out or sounding like digital garbage after a hour or so.
