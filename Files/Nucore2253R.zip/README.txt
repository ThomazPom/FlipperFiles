End-User License Agreement for Big Guy�s Pinball Nucore
This End-User License Agreement (EULA) is a legal agreement between you (either an individual or a single entity) and the mentioned author (Big Guy�s Pinball) of this Software for the software product identified above, which includes computer software and may include associated media, printed materials, and �online� or electronic documentation (�SOFTWARE PRODUCT�).
By installing, copying, or otherwise using the SOFTWARE PRODUCT, you agree to be bounded by the terms of this EULA.  If you do not agree to the terms of this EULA, do not install or use the SOFTWARE PRODUCT.

SOFTWARE PRODUCT LICENSE
a) Nucore Free Version is being distributed as Freeware for personal, non-commercial use, non-profit organization.  It may be included with CD-ROM/DVD-ROM distributions. You are NOT allowed to make a charge for distributing this Software (either for profit or merely to recover your media and distribution costs) whether as a stand-alone product, or as part of a compilation or anthology, nor to use it for supporting your business or customers. It may be distributed freely on any website or through any other distribution mechanism, as long as no part of it is changed in any way.

1. GRANT OF LICENSE. This EULA grants you the following rights: Installation and Use. You may install and use an unlimited number of copies of the SOFTWARE PRODUCT.
Reproduction and Distribution. You may reproduce and distribute an unlimited number of copies of the SOFTWARE PRODUCT; provided that each copy shall be a true and complete copy, including all copyright and trademark notices, and shall be accompanied by a copy of this EULA.
Copies of the SOFTWARE PRODUCT may be distributed as a standalone product or included with your own product as long as The SOFTWARE PRODUCT is not sold or included in a product or package that intends to receive benefits through the inclusion of the SOFTWARE PRODUCT.
The SOFTWARE PRODUCT is only for use on Pinball 2000 Pinball Machines.
2. DESCRIPTION OF OTHER RIGHTS AND LIMITATIONS.
Limitations on Reverse Engineering, Decompilation, Disassembly and change (add, delete or modify) the resources in the compiled the assembly. You may not reverse engineer, decompile, disassemble or otherwise attempt to derive the source code of this SOFTWARE PRODUCT, except and only to the extent that such activity is expressly permitted by applicable law notwithstanding this limitation.

Restriction on Alteration. You may not create any derivative work of the Software Product or its accompanying documentation. Derivative works include, but are not limited to, translations. You may not alter any files or libraries in any portion of this Software Product.

Update and Maintenance.
Big Guy�s Pinball reserves the right to charge for future releases or updates.

Separation of Components.
The SOFTWARE PRODUCT is licensed as a single product. Its component parts may not be separated for use in other products.

Software Transfer.
You may permanently transfer all of your rights under this EULA, but only if the recipient agrees to the terms of this EULA.

Termination.
Without prejudice to any other rights of the Author, the Author of this Software may terminate this EULA if you fail to comply with the terms and conditions of this EULA. In such event, you must destroy all copies of the SOFTWARE PRODUCT and all of its component parts.

3. COPYRIGHT.
All title and copyrights in and to the SOFTWARE PRODUCT (including but not limited to any images, libraries, and scripts incorporated into the SOFTWARE PRODUCT), the accompanying printed materials, and any copies of the SOFTWARE PRODUCT are owned by the Author of this Software. The SOFTWARE PRODUCT is protected by copyright laws and international treaty provisions. Therefore, you must treat the SOFTWARE PRODUCT like any other copyrighted material. The licensed users can use the SOFTWARE PRODUCT to control a Pinball 2000 Pinball Machine.

4. NO WARRANTIES.
The Author of this Software expressly disclaims any warranty for the SOFTWARE PRODUCT. The SOFTWARE PRODUCT and any related documentation is provided �As Is� without warranty of any kind, either expressed or implied, including, without limitation, the implied warranties of merchantability, fitness for a particular purpose, or non-infringement. The entire risk arising out of use or performance of the SOFTWARE PRODUCT remains with you.

5. NO LIABILITY FOR DAMAGES.
You agree that in no event shall the author of this Software be liable for any special, consequential, incidental or indirect damages whatsoever (including, without limitation, damages for loss of business profits, business interruption, loss of business information, or any other pecuniary loss) arising out of the use of or inability to use this product, even if the Author of this Software is aware of the possibility of such damages and known defects.

6. GOVERNING LAW, JURISDICTION AND COSTS
This Agreement is governed by the laws of Michigan, without regard to Michigan�s conflict or choice of law provisions.
