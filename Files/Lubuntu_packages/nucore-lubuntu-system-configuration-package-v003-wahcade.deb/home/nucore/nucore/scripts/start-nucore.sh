#!/bin/bash

#
# start nucore
#

cd /home/nucore/nucore/bin
./run nucore -bpp 16 -fullscreen&

# 
# 15khz hack 
#

sleep 3
#/home/nucore/nucore/scripts/15khz-x11.sh