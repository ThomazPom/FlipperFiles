#!/bin/bash

# enable Nucore autostart

rm /home/nucore/.config/autostart/start-nucore.desktop