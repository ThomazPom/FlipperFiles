#!/bin/bash

#
# Modeline for the original Pinball 2000 CRT monitors
#
# You might have to change the port "VGA-0" to match your graphic card port, which is connected to the P2k CRT monitor.
#
# run "xrandr --display
# example:
# xrandr --listmonitors
# Monitors: 1
 # 0: +*VGA-0 1568/415x821/217+0+0  VGA-0  
#


xrandr --newmode "640x480-15khz" 13.218975 640 672 736 840 480 484 490 525 -HSync -VSync interlace
xrandr --addmode VGA-0 "640x480-15khz"
xrandr --output VGA-0 --mode "640x480-15khz"