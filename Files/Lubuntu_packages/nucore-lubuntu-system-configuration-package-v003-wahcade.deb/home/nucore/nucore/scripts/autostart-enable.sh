#!/bin/bash

# enable Nucore autostart

cp -f /home/nucore/nucore/scripts/confs/start-nucore.desktop /home/nucore/.config/autostart