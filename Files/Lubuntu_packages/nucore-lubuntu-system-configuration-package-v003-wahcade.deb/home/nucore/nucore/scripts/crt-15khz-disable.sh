#!/bin/bash

# disable 15 khz (for the original CRT monitor)

sed -i "s/^\/home\/nucore\/nucore\/scripts\/15khz-x11\.sh.*/\#\/home\/nucore\/nucore\/scripts\/15khz-x11\.sh/" /home/nucore/nucore/scripts/start-nucore.sh